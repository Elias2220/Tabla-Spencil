// Importacion de los modulos
const express = require('express');
const cors = require('cors');
// Inicializacion de la aplicacion
const app = express();
//Puerto que se usa
const port = 3000;
//Configuracion Middleware
app.use(cors());

// Datos simulados
const furnitureData = [
  { id: 1, name: 'Silla', material: 'Madera', price: 25 },
  { id: 2, name: 'Tabla', material: 'Metal', price: 150 },
  { id: 3, name: 'Escritorio', material: 'Madera', price: 100 },
  { id: 4, name: 'Mueble', material: 'Plastico', price: 50 },
];

// Endpoint para obtener los datos
app.get('/furniture', (req, res) => {
  res.json(furnitureData);
});
//Inicio del servidor
app.listen(port, () => {
  console.log(`API listening at http://localhost:${port}`);
});
