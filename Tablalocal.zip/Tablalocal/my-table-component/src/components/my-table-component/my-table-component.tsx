import { Component, Prop, State, h } from '@stencil/core';

@Component({
  tag: 'my-table-component',
  styleUrl: 'my-table-component.css',
  shadow: true,
})
export class MyTableComponent {
  @Prop() apiUrl: string;
  @State() data: any[] = [];
  @State() error: string;

  async componentWillLoad() {
    try {
      const response = await fetch(this.apiUrl);
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      const json = await response.json();
      this.data = json;
    } catch (err) {
      this.error = err.message;
    }
  }

  render() {
    if (this.error) {
      return <div>Error: {this.error}</div>;
    }

    if (this.data.length === 0) {
      return <div>Loading...</div>;
    }

    const headers = Object.keys(this.data[0]);

    return (
      <div class="table-container">
        <table>
          <thead>
            <tr>
              {headers.map(header => (
                <th>{header}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {this.data.map(item => (
              <tr>
                {headers.map(header => (
                  <td>{item[header]}</td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  }
}
